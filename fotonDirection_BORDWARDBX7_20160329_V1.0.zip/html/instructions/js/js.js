body =  document.body;
bodywidth=window.innerWidth;
bodyheight=window.innerHeight;

var isDesktop = navigator['userAgent'].match(/(android|windows phone|windows)/i) ? false : true;
var des = (!isDesktop)? 'click':'touchstart';

window.ontouchstart = function(e) { e.stopPropagation();e.preventDefault(); };
window.ontouchmove = function(e) { e.stopPropagation();e.preventDefault(); };
window.onmousedown = function(e) { e.stopPropagation();e.preventDefault(); };
window.onmousemove = function(e) { e.stopPropagation();e.preventDefault(); };

var animating = 0;
var decisionVal = 80;
var pullDeltaY = 0;

$(document).ready(function(){
    $(".load").css({'height':0.12*bodywidth+'px','margin-top':-0.06*bodywidth+'px'});
    $(".circle_page2,.circle_page3,.circle_page4,.circle_page5").css('height',0.03*bodywidth+'px');
    $(".arrow").css('height',0.077*bodywidth+'px');
});
//*******************************page2*******************************
$(document).on(des, '.tab_frame1',function (event) {
    event.stopPropagation();
    event.preventDefault();
    $('.main1_page2,.line_1,.text_1,.tab_1_page2').css('display','none');
    $('.button_page2,.line_2,.text_2').css('display','block');
    $('.circle_page2').css('transform','translateX(1200%)');
});
$(document).on(des, '.tab_frame2',function (event) {
    event.stopPropagation();event.preventDefault();
    $('.button_page2,.line_2,.text_2').css('display','none');
    $('.main1_page2,.line_1,.text_1,.tab_1_page2').css('display','block');
    $('.circle_page2').css('transform','translateX(0%)');
});

//*******************************page3*******************************

$(document).on(des, '.button_page3',function () {
    $('.main1_page3,.scan_cont_page3,.button_page3,.circle_page3').css('display','none');
});


//*******************************page4*******************************
$(document).on(des, '.search_frame1_page4',function () { 
    $('.main1_page41,.scan_cont_page4,.search_frame1_page4').css('display','none');
    $('.tab_frame2_page4').css('display','block');
    $('.circle_page4').css('transform','translate(-1300%,400%)');
});
$(document).on(des, '.tab_frame2_page4',function () {
    $('.main1_page42,.tab_frame2_page4').css('display','none');
    $('.voice_frame3_page4').css('display','block');
    $('.circle_page4').css('transform','translate(-231%,80%)');
});
$(document).on(des, '.voice_frame3_page4',function () {
    $('.voice_frame3_page4').css('display','none');
    $('.voice').css('display','block');
    $('.circle_page4').css('transform','translate(-771%,2840%)');
});

//*******************************page5*******************************
$(document).on(des, '.instruction_frame1_page5',function () {
    $('.main1_page51,.scan_cont_page5,.instruction_frame1_page5').css('display','none');
    $('.menu_frame2_page5').css('display','block');
    $('.circle_page5').css('transform','translate(-400%,1300%)');
});
$(document).on(des, '.menu_frame2_page5',function () {
    $('.main2_page51,.circle_page5').css('display','none');
});



//*******************************滑屏事件*******************************
$(document).on('mousedown touchstart', function (e) {
    e.stopPropagation();e.preventDefault();
    startY = e.pageY || e.originalEvent.touches[0].pageY;
    animating = 1;
});
$(document).on('mousemove touchmove', function (event) {
    if(animating == 1){
        pullChange(event);
    }   
    
});
$(document).on('mouseup touchend', function () {
    if(animating == 1){
        if (!pullDeltaY){
            animating = 0;
            return;
        }
        release();
        animating = 0;
    }
});
function pullChange(event) {
    var y = event.pageY || event.originalEvent.touches[0].pageY;
    pullDeltaY = y - startY;
}
var page_cur = 1;
function release(event) {
    if (pullDeltaY >= decisionVal) {

        //移动距离超过80时当前页隐藏，新页面显示
        $('.page_' + page_cur).css('display','none');
        if(page_cur>1){
            page_cur--;
        }
        $('.page_' + page_cur).css('display','block');

        //恢复到每页初始状态
        if(page_cur==1){
            $('.button_page2,.line_2,.text_2').css('display','none');
            $('.main1_page2,.line_1,.text_1,.tab_1_page2').css('display','block');
            $('.circle_page2').css('transform','translateX(0%)');
        }
        if(page_cur==2){
            $('.main1_page3,.scan_cont_page3,.button_page3,.circle_page3').css('display','block');
        }
        if(page_cur==3){
            setTimeout(function(){
                $('.circle_page3').css('display','block');
            },2000);
            $('.main1_page41,.main1_page42,.scan_cont_page4,.search_frame1_page4').css('display','block');
            $('.tab_frame2_page4,.voice_frame3_page4,.voice').css('display','none');
            $('.circle_page4').css('transform','translate(0%,0%)');
        }
        if(page_cur==4){
            $('.main1_page51,.main2_page51,.scan_cont_page5,.circle_page5,.instruction_frame1_page5').css('display','block');
            $('.menu_frame2_page5').css('display','none');
            $('.circle_page5').css('transform','translate(0%,0%)');
        }
    } else if (pullDeltaY <= -decisionVal) {

        //移动距离小于-80时当前页隐藏，新页面显示
        $('.page_' + page_cur).css('display','none');
        if(page_cur<=4){
            page_cur++;
        }
        $('.page_' + page_cur).css('display','block');

        //恢复到每页初始状态
        if(page_cur==3){
            setTimeout(function(){
                $('.circle_page3').css('display','block');
            },2000);
            $('.button_page2,.line_2,.text_2').css('display','none');
            $('.main1_page2,.line_1,.text_1,.tab_1_page2').css('display','block');
            $('.circle_page2').css('transform','translateX(0%)');
        }
        if(page_cur==4){
            $('.main1_page3,.scan_cont_page3,.button_page3,.circle_page3').css('display','block');
        }
        if(page_cur==5){
            $('.main1_page41,.main1_page42,.scan_cont_page4,.search_frame1_page4').css('display','block');
            $('.tab_frame2_page4,.voice_frame3_page4,.voice').css('display','none');
            $('.circle_page4').css('transform','translate(0%,0%)');
        }
    }
    pullDeltaY = 0;
}