body =  document.body;
bodywidth=window.innerWidth;
bodyheight=window.innerHeight;

var isDesktop = navigator['userAgent'].match(/(android|windows phone|windows)/i) ? false : true;
var des = (!isDesktop)? 'click':'touchstart';

var headstr1 = "<div class='headPic'><img src='images/sound/head";
var headstr2 = ".png'></div><div class='headText'><p>"

$(document).ready(function(){
    $(".headCont").children().append(function(n){
        return  headstr1+ n + headstr2 + json.soundHead[n].title +"</p></div>";
    });

    $(".arrow").css('border-right','solid '+0.007*bodywidth+'px white');
    $(".arrow").css('border-bottom','solid '+0.007*bodywidth+'px white');
    $(".container").find(".title").attr("data-arrow","0");


    $(".title").click(function(){
        $(this).next().slideToggle();
        if($(this).attr("data-arrow") == 0){
            $(this).attr("data-arrow","1");
            $(this).children(".arrow").css('transform','rotate(45deg)');
        }else{
            $(this).attr("data-arrow","0");
            $(this).children(".arrow").css('transform','rotate(-45deg)');
        }
        $(this).children("img").attr('src','images/title'+ $(this).attr("data-arrow") +'.png');
    });

});