body =  document.body;
bodywidth=window.innerWidth;
bodyheight=window.innerHeight;

var isDesktop = navigator['userAgent'].match(/(android|windows phone|windows)/i) ? false : true;
var des = (!isDesktop)? 'click':'touchstart';
//标题背景图片及每个模块的标题
var str1= "<div class='title'><img src='images/title0.png'><span class='icon'><img src='images/maintenance/icon";
//下拉箭头及模块图片
var str2=".png'></span><div class='titleText'>"
var str3="</div><div class='arrow'></div></div><div class='description'><video class='video' preload='auto' poster='images/maintenance/poster0.png' src='images/maintenance/";

var headstr1 = "<div class='headPic'><img src='images/maintenance/head";
var headstr2 = ".png'></div><div class='headText'><p>"

$(document).ready(function(){
    $(".container").children().append(function(n){
        // return  str1+ n + str2 + json.maintenance[n].title + str3 + n + ".mp4'></video><div class='warning'><div class='warning_title'>"+ json.maintenance[n].tip[0].title +"</div><div class='warning_cont'>"+ json.maintenance[n].tip[0].cont +" </div></div></div>";
        return  str1+ n + str2 + json.maintenance[n].title + str3 +  "0.mp4'></video><div class='warning'><div class='warning_title'>"+ json.maintenance[n].tip[0].title +"</div><div class='warning_cont'>"+ json.maintenance[n].tip[0].cont +" </div></div></div>";
    });

    $(".headCont").children().append(function(n){
        return  headstr1+ n + headstr2 + json.maintenanceHead[n].title +"</p></div>";
    });


    $(".arrow").css('border-right','solid '+0.007*bodywidth+'px white');
    $(".arrow").css('border-bottom','solid '+0.007*bodywidth+'px white');
    $(".container").find(".title").attr("data-arrow","0");


    $(".title").click(function(){
        $(this).next().slideToggle();
        if($(this).attr("data-arrow") == 0){
            $(this).attr("data-arrow","1");
            $(this).children(".arrow").css('transform','rotate(45deg)');
        }else{
            $(this).attr("data-arrow","0");
            $(this).children(".arrow").css('transform','rotate(-45deg)');
        }
        $(this).children("img").attr('src','images/title'+ $(this).attr("data-arrow") +'.png');
    });

});